# Chess game Documentation

This is the documentation for chess game.

## Installation

To install my project, follow these steps:

1. Clone the repository.
2. Run `make` to compile the project.
3. Run `./jahelluk` to run_tutorial the project.

## Usage

To use my project, run_tutorial `./jahelluk` and follow the on-screen prompts.

